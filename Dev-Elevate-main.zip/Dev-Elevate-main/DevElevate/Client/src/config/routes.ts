export const baseUrl: string = import.meta.env.VITE_API_URL;


export const adminApi = {
  allUser: "/api/v1/admin/all-users",
  addUser:"/api/v1/admin/add-user",
  deleteUser:"/api/v1/admin/delete-user"


  
}